-- Change DTEC946 to a node name for your environment
-- Change STLEC1 to the z/os database name
-- Change DTEC946.vmec.svl.ibm.com to the IP address of the z/os server
uncatalog tcpip node DTEC946;
uncatalog database STLEC1;
catalog tcpip node DTEC946 remote DTEC946.vmec.svl.ibm.com server 446;
catalog database STLEC1 at node DTEC946;