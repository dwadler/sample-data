-- Change LUWNODE to a node name for your environment
-- Change 192.168.0.2 to the IP address of the DB2 LUW server
-- Change SAMP105 to the remote database name
-- Change SAMP1052 to an alias to use locally to connect
uncatalog node LUWNODE;
uncatalog database SAMP105;
catalog tcpip node LUWNODE remote 192.168.0.2 server 50000;
catalog database SAMP105 as SAMP1052 at node LUWNODE;